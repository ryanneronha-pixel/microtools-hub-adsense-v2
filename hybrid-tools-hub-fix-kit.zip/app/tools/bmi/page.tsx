'use client'
import { useMemo, useState } from 'react'
import AdSenseSlot from '@/components/AdSenseSlot'

function classify(bmi:number){
  if (bmi < 18.5) return 'Underweight'
  if (bmi < 25) return 'Normal'
  if (bmi < 30) return 'Overweight'
  return 'Obesity'
}

export default function BMIPage(){
  const [kg, setKg] = useState(70)
  const [cm, setCm] = useState(175)
  const bmi = useMemo(()=>{
    const m = cm / 100
    return m>0 ? kg/(m*m) : 0
  }, [kg, cm])

  return (
    <section className="grid" style={{gap:16}}>
      <h1 style={{margin:0}}>BMI Calculator</h1>
      <AdSenseSlot slot="0000002001" />
      <div className="card grid grid-3">
        <div><label className="label">Weight (kg)</label><input className="input" type="number" value={kg} onChange={e=>setKg(parseFloat(e.target.value||'0'))} /></div>
        <div><label className="label">Height (cm)</label><input className="input" type="number" value={cm} onChange={e=>setCm(parseFloat(e.target.value||'0'))} /></div>
        <div className="center">
          <div className="small">BMI</div>
          <div style={{fontWeight:800,fontSize:'22px'}}>{bmi?bmi.toFixed(1):'—'}</div>
          <div className="small">{bmi?classify(bmi):''}</div>
        </div>
      </div>
      <AdSenseSlot slot="0000002002" />
    </section>
  )
}
