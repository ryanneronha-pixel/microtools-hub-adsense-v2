'use client'
import { useState } from 'react'
import AdSenseSlot from '@/components/AdSenseSlot'

export default function CoinFlipPage(){
  const [side, setSide] = useState<'Heads'|'Tails'|'—'>('—' as any)
  const flip = () => setSide(Math.random()<0.5 ? 'Heads' : 'Tails')
  return (
    <section className="grid" style={{gap:16}}>
      <h1 style={{margin:0}}>Coin Flip</h1>
      <AdSenseSlot slot="0000005001" />
      <div className="card center">
        <div className="small">Result</div>
        <div style={{fontWeight:800,fontSize:'28px',margin:'8px 0'}}>{side}</div>
        <button className="btn" onClick={flip}>Flip</button>
      </div>
      <AdSenseSlot slot="0000005002" />
    </section>
  )
}
