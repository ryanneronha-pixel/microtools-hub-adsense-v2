import Link from 'next/link'
export default function Tools(){
  const items = [
    { slug:'bmi', title:'BMI Calculator' },
    { slug:'loan', title:'Loan Calculator' },
    { slug:'name-generator', title:'Random Name Generator' },
    { slug:'coin-flip', title:'Coin Flip' },
  ]
  return (
    <section className="grid" style={{gap:16}}>
      <h1 style={{margin:0}}>All Tools</h1>
      <div className="grid grid-2">
        {items.map(t => <Link key={t.slug} href={`/tools/${t.slug}`} className="card">{t.title}</Link>)}
      </div>
    </section>
  )
}
