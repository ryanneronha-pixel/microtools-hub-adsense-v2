'use client'
import { useMemo, useState } from 'react'
import AdSenseSlot from '@/components/AdSenseSlot'

function pmt(rate:number, nper:number, pv:number){
  const r = rate/12
  return r===0 ? pv/nper : (pv*r)/(1 - Math.pow(1+r, -nper))
}

export default function LoanPage(){
  const [amount, setAmount] = useState(25000)
  const [apr, setApr] = useState(6.5)
  const [years, setYears] = useState(5)

  const monthly = useMemo(()=>pmt(apr/100, years*12, amount), [apr, years, amount])
  const total = monthly * years * 12

  return (
    <section className="grid" style={{gap:16}}>
      <h1 style={{margin:0}}>Loan Calculator</h1>
      <AdSenseSlot slot="0000003001" />
      <div className="card grid grid-3">
        <div><label className="label">Amount</label><input className="input" type="number" value={amount} onChange={e=>setAmount(parseFloat(e.target.value||'0'))} /></div>
        <div><label className="label">APR %</label><input className="input" type="number" value={apr} onChange={e=>setApr(parseFloat(e.target.value||'0'))} /></div>
        <div><label className="label">Years</label><input className="input" type="number" value={years} onChange={e=>setYears(parseInt(e.target.value||'0'))} /></div>
      </div>
      <div className="card grid grid-2">
        <div><div className="small">Monthly payment</div><div style={{fontWeight:700}}>${monthly.toFixed(2)}</div></div>
        <div><div className="small">Total paid</div><div style={{fontWeight:700}}>${total.toFixed(2)}</div></div>
      </div>
      <AdSenseSlot slot="0000003002" />
    </section>
  )
}
