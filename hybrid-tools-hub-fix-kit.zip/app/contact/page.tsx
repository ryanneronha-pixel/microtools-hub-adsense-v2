export default function Contact(){
  return (
    <section className="card">
      <h1 style={{marginTop:0}}>Contact</h1>
      <p>Email us at <a href="mailto:hello@example.com">hello@example.com</a> for support or takedowns.</p>
    </section>
  )
}
