export default function Privacy(){
  return (
    <section className="card">
      <h1 style={{marginTop:0}}>Privacy Policy (Starter)</h1>
      <p>This site uses Google AdSense to serve ads. AdSense may use cookies or device identifiers to provide and measure ads. You can manage ad personalization in your Google account.</p>
      <p>We do not collect personal information unless you contact us. Basic analytics (page views, referrers) may be used to improve the site.</p>
      <p>For questions, see the Contact page.</p>
    </section>
  )
}
